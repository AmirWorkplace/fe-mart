<link rel="stylesheet" href="{{ asset('frontend/assets/css/plugin.css') }}">
<link rel="stylesheet" href="{{ asset('frontend/assets/css/fonts.min.css') }}">
<link rel="stylesheet" href="{{ asset('frontend/assets/css/nivo-slider.css') }}">
<link rel="stylesheet" href="{{ asset('frontend/assets/css/select2.min.css') }}">
@stack('css')
<link rel="stylesheet" href="{{ asset('frontend/assets/css/style.css') }}">
<link rel="stylesheet" href="{{ asset('frontend/assets/css/responsive.css') }}">
