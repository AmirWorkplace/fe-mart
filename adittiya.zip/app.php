<script>
  const data = (id) =>  ({
    '50': {
      name: 'dress',

    },
  })
</script>