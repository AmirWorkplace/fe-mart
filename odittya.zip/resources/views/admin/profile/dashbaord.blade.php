@extends('layouts.admin.app')
@push('css')
<style>
    .count {
        /* min-width: 60px;
        background-color: rgb(0 0 0 / 10%);
        display: inline-grid;
        place-items: center;
        border-radius: 5px; */
        font-size: 22px;
        padding: 5px;
        position: relative;
    }

</style>
@endpush
@section('content')
<div class="row g-4">
    <div class="col-12">

    </div>
</div>
@endsection
