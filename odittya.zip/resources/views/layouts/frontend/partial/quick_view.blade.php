<div class="modal fade custom-modal" id="quickViewModal" tabindex="-1" aria-labelledby="quickViewModalLabel" aria-hidden="true">
    <div class="modal-dialog modal-lg modal-dialog-centered">
        <div class="modal-content">
            <div class="modal-body">
                <button type="button" class="btn close-quick-view" data-bs-dismiss="modal" aria-label="Close"><i
                        class="far fa-times"></i></button>
                <div id="item_wrapper">
                </div>
            </div>
        </div>
    </div>
</div>
