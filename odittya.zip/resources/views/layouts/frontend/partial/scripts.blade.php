<script type="text/javascript" src="{{ asset('frontend/assets/js/plugin.js') }}"></script>
<script type="text/javascript" src="{{ asset('frontend/assets/js/jquery.nivo.slider.js') }}"></script>
<script type="text/javascript" src="{{ asset('frontend/assets/js/select2.min.js') }}"></script>
<script src="//cdn.jsdelivr.net/npm/sweetalert2@11"></script>
<script type="text/javascript" src="{{ asset('frontend/assets/js/script.js') }}"></script>
